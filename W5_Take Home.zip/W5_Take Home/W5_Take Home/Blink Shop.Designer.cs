﻿namespace W5_Take_Home
{
    partial class Form_BlinkShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewCategory = new System.Windows.Forms.DataGridView();
            this.cbx_Filter = new System.Windows.Forms.ComboBox();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.btn_All = new System.Windows.Forms.Button();
            this.dataGridViewProduk = new System.Windows.Forms.DataGridView();
            this.lb_Details = new System.Windows.Forms.Label();
            this.lb_Category = new System.Windows.Forms.Label();
            this.lb_Product = new System.Windows.Forms.Label();
            this.lb_NamaCat = new System.Windows.Forms.Label();
            this.tb_NamaCat = new System.Windows.Forms.TextBox();
            this.btn_AddCat = new System.Windows.Forms.Button();
            this.btn_RemoveCat = new System.Windows.Forms.Button();
            this.lb_NamaPro = new System.Windows.Forms.Label();
            this.lb_CategoryPro = new System.Windows.Forms.Label();
            this.lb_Harga = new System.Windows.Forms.Label();
            this.lb_Stock = new System.Windows.Forms.Label();
            this.tb_NamaPro = new System.Windows.Forms.TextBox();
            this.tb_Stock = new System.Windows.Forms.TextBox();
            this.tb_Harga = new System.Windows.Forms.TextBox();
            this.cbx_CategoryPro = new System.Windows.Forms.ComboBox();
            this.btn_AddPro = new System.Windows.Forms.Button();
            this.btn_EditPro = new System.Windows.Forms.Button();
            this.btn_RemovePro = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduk)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewCategory
            // 
            this.dataGridViewCategory.AllowUserToAddRows = false;
            this.dataGridViewCategory.AllowUserToDeleteRows = false;
            this.dataGridViewCategory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCategory.Location = new System.Drawing.Point(614, 91);
            this.dataGridViewCategory.Name = "dataGridViewCategory";
            this.dataGridViewCategory.RowHeadersVisible = false;
            this.dataGridViewCategory.RowHeadersWidth = 62;
            this.dataGridViewCategory.RowTemplate.Height = 28;
            this.dataGridViewCategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCategory.Size = new System.Drawing.Size(323, 267);
            this.dataGridViewCategory.TabIndex = 15;
            this.dataGridViewCategory.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCategory_CellClick);
            // 
            // cbx_Filter
            // 
            this.cbx_Filter.Enabled = false;
            this.cbx_Filter.FormattingEnabled = true;
            this.cbx_Filter.Location = new System.Drawing.Point(377, 54);
            this.cbx_Filter.Name = "cbx_Filter";
            this.cbx_Filter.Size = new System.Drawing.Size(148, 28);
            this.cbx_Filter.TabIndex = 14;
            this.cbx_Filter.SelectedIndexChanged += new System.EventHandler(this.cbx_Filter_SelectedIndexChanged);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(306, 53);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(64, 29);
            this.btn_Filter.TabIndex = 13;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(255, 53);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(47, 29);
            this.btn_All.TabIndex = 12;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // dataGridViewProduk
            // 
            this.dataGridViewProduk.AllowUserToAddRows = false;
            this.dataGridViewProduk.AllowUserToDeleteRows = false;
            this.dataGridViewProduk.AllowUserToOrderColumns = true;
            this.dataGridViewProduk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProduk.ColumnHeadersHeight = 34;
            this.dataGridViewProduk.Location = new System.Drawing.Point(36, 91);
            this.dataGridViewProduk.Name = "dataGridViewProduk";
            this.dataGridViewProduk.RowHeadersVisible = false;
            this.dataGridViewProduk.RowHeadersWidth = 62;
            this.dataGridViewProduk.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProduk.Size = new System.Drawing.Size(527, 345);
            this.dataGridViewProduk.TabIndex = 8;
            this.dataGridViewProduk.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProduk_CellClick);
            // 
            // lb_Details
            // 
            this.lb_Details.AutoSize = true;
            this.lb_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Details.Location = new System.Drawing.Point(30, 465);
            this.lb_Details.Name = "lb_Details";
            this.lb_Details.Size = new System.Drawing.Size(109, 32);
            this.lb_Details.TabIndex = 11;
            this.lb_Details.Text = "Details";
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(608, 27);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(137, 32);
            this.lb_Category.TabIndex = 10;
            this.lb_Category.Text = "Category";
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(30, 27);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(119, 32);
            this.lb_Product.TabIndex = 9;
            this.lb_Product.Text = "Product";
            // 
            // lb_NamaCat
            // 
            this.lb_NamaCat.AutoSize = true;
            this.lb_NamaCat.Location = new System.Drawing.Point(610, 374);
            this.lb_NamaCat.Name = "lb_NamaCat";
            this.lb_NamaCat.Size = new System.Drawing.Size(55, 20);
            this.lb_NamaCat.TabIndex = 16;
            this.lb_NamaCat.Text = "Nama:";
            // 
            // tb_NamaCat
            // 
            this.tb_NamaCat.Location = new System.Drawing.Point(702, 371);
            this.tb_NamaCat.Name = "tb_NamaCat";
            this.tb_NamaCat.Size = new System.Drawing.Size(235, 26);
            this.tb_NamaCat.TabIndex = 17;
            // 
            // btn_AddCat
            // 
            this.btn_AddCat.Location = new System.Drawing.Point(763, 403);
            this.btn_AddCat.Name = "btn_AddCat";
            this.btn_AddCat.Size = new System.Drawing.Size(85, 56);
            this.btn_AddCat.TabIndex = 18;
            this.btn_AddCat.Text = "Add Category";
            this.btn_AddCat.UseVisualStyleBackColor = true;
            this.btn_AddCat.Click += new System.EventHandler(this.btn_AddCat_Click);
            // 
            // btn_RemoveCat
            // 
            this.btn_RemoveCat.Location = new System.Drawing.Point(852, 403);
            this.btn_RemoveCat.Name = "btn_RemoveCat";
            this.btn_RemoveCat.Size = new System.Drawing.Size(85, 56);
            this.btn_RemoveCat.TabIndex = 19;
            this.btn_RemoveCat.Text = "Remove Category";
            this.btn_RemoveCat.UseVisualStyleBackColor = true;
            this.btn_RemoveCat.Click += new System.EventHandler(this.btn_RemoveCat_Click);
            // 
            // lb_NamaPro
            // 
            this.lb_NamaPro.AutoSize = true;
            this.lb_NamaPro.Location = new System.Drawing.Point(35, 518);
            this.lb_NamaPro.Name = "lb_NamaPro";
            this.lb_NamaPro.Size = new System.Drawing.Size(55, 20);
            this.lb_NamaPro.TabIndex = 20;
            this.lb_NamaPro.Text = "Nama:";
            // 
            // lb_CategoryPro
            // 
            this.lb_CategoryPro.AutoSize = true;
            this.lb_CategoryPro.Location = new System.Drawing.Point(9, 557);
            this.lb_CategoryPro.Name = "lb_CategoryPro";
            this.lb_CategoryPro.Size = new System.Drawing.Size(81, 20);
            this.lb_CategoryPro.TabIndex = 21;
            this.lb_CategoryPro.Text = "Category: ";
            // 
            // lb_Harga
            // 
            this.lb_Harga.AutoSize = true;
            this.lb_Harga.Location = new System.Drawing.Point(33, 597);
            this.lb_Harga.Name = "lb_Harga";
            this.lb_Harga.Size = new System.Drawing.Size(57, 20);
            this.lb_Harga.TabIndex = 22;
            this.lb_Harga.Text = "Harga:";
            // 
            // lb_Stock
            // 
            this.lb_Stock.AutoSize = true;
            this.lb_Stock.Location = new System.Drawing.Point(36, 637);
            this.lb_Stock.Name = "lb_Stock";
            this.lb_Stock.Size = new System.Drawing.Size(54, 20);
            this.lb_Stock.TabIndex = 23;
            this.lb_Stock.Text = "Stock:";
            // 
            // tb_NamaPro
            // 
            this.tb_NamaPro.Location = new System.Drawing.Point(113, 515);
            this.tb_NamaPro.Name = "tb_NamaPro";
            this.tb_NamaPro.Size = new System.Drawing.Size(412, 26);
            this.tb_NamaPro.TabIndex = 24;
            // 
            // tb_Stock
            // 
            this.tb_Stock.Location = new System.Drawing.Point(113, 631);
            this.tb_Stock.Name = "tb_Stock";
            this.tb_Stock.Size = new System.Drawing.Size(150, 26);
            this.tb_Stock.TabIndex = 26;
            this.tb_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Stock_KeyPress);
            // 
            // tb_Harga
            // 
            this.tb_Harga.Location = new System.Drawing.Point(113, 594);
            this.tb_Harga.Name = "tb_Harga";
            this.tb_Harga.Size = new System.Drawing.Size(150, 26);
            this.tb_Harga.TabIndex = 27;
            this.tb_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // cbx_CategoryPro
            // 
            this.cbx_CategoryPro.FormattingEnabled = true;
            this.cbx_CategoryPro.Location = new System.Drawing.Point(113, 553);
            this.cbx_CategoryPro.Name = "cbx_CategoryPro";
            this.cbx_CategoryPro.Size = new System.Drawing.Size(150, 28);
            this.cbx_CategoryPro.TabIndex = 28;
            // 
            // btn_AddPro
            // 
            this.btn_AddPro.Location = new System.Drawing.Point(277, 597);
            this.btn_AddPro.Name = "btn_AddPro";
            this.btn_AddPro.Size = new System.Drawing.Size(87, 56);
            this.btn_AddPro.TabIndex = 29;
            this.btn_AddPro.Text = "Add Product";
            this.btn_AddPro.UseVisualStyleBackColor = true;
            this.btn_AddPro.Click += new System.EventHandler(this.btn_AddPro_Click);
            // 
            // btn_EditPro
            // 
            this.btn_EditPro.Location = new System.Drawing.Point(363, 597);
            this.btn_EditPro.Name = "btn_EditPro";
            this.btn_EditPro.Size = new System.Drawing.Size(80, 56);
            this.btn_EditPro.TabIndex = 30;
            this.btn_EditPro.Text = "Edit Product";
            this.btn_EditPro.UseVisualStyleBackColor = true;
            this.btn_EditPro.Click += new System.EventHandler(this.btn_EditPro_Click);
            // 
            // btn_RemovePro
            // 
            this.btn_RemovePro.Location = new System.Drawing.Point(442, 597);
            this.btn_RemovePro.Name = "btn_RemovePro";
            this.btn_RemovePro.Size = new System.Drawing.Size(83, 56);
            this.btn_RemovePro.TabIndex = 31;
            this.btn_RemovePro.Text = "Remove Product";
            this.btn_RemovePro.UseVisualStyleBackColor = true;
            this.btn_RemovePro.Click += new System.EventHandler(this.btn_RemovePro_Click);
            // 
            // Form_BlinkShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(962, 693);
            this.Controls.Add(this.btn_RemovePro);
            this.Controls.Add(this.btn_EditPro);
            this.Controls.Add(this.btn_AddPro);
            this.Controls.Add(this.cbx_CategoryPro);
            this.Controls.Add(this.tb_Harga);
            this.Controls.Add(this.tb_Stock);
            this.Controls.Add(this.tb_NamaPro);
            this.Controls.Add(this.lb_Stock);
            this.Controls.Add(this.lb_Harga);
            this.Controls.Add(this.lb_CategoryPro);
            this.Controls.Add(this.lb_NamaPro);
            this.Controls.Add(this.btn_RemoveCat);
            this.Controls.Add(this.btn_AddCat);
            this.Controls.Add(this.tb_NamaCat);
            this.Controls.Add(this.lb_NamaCat);
            this.Controls.Add(this.dataGridViewCategory);
            this.Controls.Add(this.cbx_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.dataGridViewProduk);
            this.Controls.Add(this.lb_Details);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.lb_Product);
            this.Name = "Form_BlinkShop";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form_BlinkShop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewCategory;
        private System.Windows.Forms.ComboBox cbx_Filter;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.DataGridView dataGridViewProduk;
        private System.Windows.Forms.Label lb_Details;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.Label lb_Product;
        private System.Windows.Forms.Label lb_NamaCat;
        private System.Windows.Forms.TextBox tb_NamaCat;
        private System.Windows.Forms.Button btn_AddCat;
        private System.Windows.Forms.Button btn_RemoveCat;
        private System.Windows.Forms.Label lb_NamaPro;
        private System.Windows.Forms.Label lb_CategoryPro;
        private System.Windows.Forms.Label lb_Harga;
        private System.Windows.Forms.Label lb_Stock;
        private System.Windows.Forms.TextBox tb_NamaPro;
        private System.Windows.Forms.TextBox tb_Stock;
        private System.Windows.Forms.TextBox tb_Harga;
        private System.Windows.Forms.ComboBox cbx_CategoryPro;
        private System.Windows.Forms.Button btn_AddPro;
        private System.Windows.Forms.Button btn_EditPro;
        private System.Windows.Forms.Button btn_RemovePro;
    }
}

