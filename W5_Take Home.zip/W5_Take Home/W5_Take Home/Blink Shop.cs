﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W5_Take_Home
{
    public partial class Form_BlinkShop : Form
    {
        DataTable dtProduct; //bwt product all
        DataTable dtCategory; //bwt kategori
        DataTable dtProductTampil; //bwt produk filter

        bool kembar = false;

        string awalInput;
        string awalTabel;
        string awalTampil;
        string simpanCatPro;

        int simpanindeks = 0;
        public Form_BlinkShop()
        {
            InitializeComponent();
            BackColor = Color.LightSalmon;
            btn_AddPro.BackColor = Color.LimeGreen;
            btn_EditPro.BackColor = Color.Yellow;
            btn_RemovePro.BackColor = Color.Red;
            btn_AddCat.BackColor = Color.LimeGreen;
            btn_RemoveCat.BackColor = Color.Red;
        }

        private void Form_BlinkShop_Load(object sender, EventArgs e)
        {
            cbx_Filter.Enabled = false;

            dtProduct = new DataTable();
            dtProduct.Columns.Add("ID Product");
            dtProduct.Columns.Add("Nama Product");
            dtProduct.Columns.Add("Harga");
            dtProduct.Columns.Add("Stock");
            dtProduct.Columns.Add("ID Category");
            dtProduct.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProduct.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProduct.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProduct.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProduct.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProduct.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProduct.Rows.Add("C002", "Cawat Blink-blink", "1000000", "1", "C5");
            dtProduct.Rows.Add("R002", "Roca Shirt", "50000", "8", "C2");
            dataGridViewProduk.DataSource = dtProduct;

            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dataGridViewCategory.DataSource = dtCategory;

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cbx_CategoryPro.Items.Add(dtCategory.Rows[i][1]);
                cbx_Filter.Items.Add(dtCategory.Rows[i][1]);
            }

            dataGridViewProduk.ClearSelection();
            dataGridViewCategory.ClearSelection();
        }

        private void dataGridViewProduk_CellClick(object sender, DataGridViewCellEventArgs e)
        { 
            DataGridViewRow dgvrPro = dataGridViewProduk.CurrentRow;

            tb_NamaPro.Text = dgvrPro.Cells[1].Value.ToString();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dgvrPro.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    cbx_CategoryPro.Text = dtCategory.Rows[i][1].ToString();
                    break;
                }
            }

            tb_Harga.Text = dgvrPro.Cells[2].Value.ToString();
            tb_Stock.Text = dgvrPro.Cells[3].Value.ToString();

        }

        private void dataGridViewCategory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvrCat = dataGridViewCategory.CurrentRow;
            tb_NamaCat.Text = dgvrCat.Cells[1].Value.ToString();
        }

        private void btn_AddCat_Click(object sender, EventArgs e)
        {
            if (tb_NamaCat.Text.Length == 0)
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu", "Eror", MessageBoxButtons.OK);
            }
            else
            {
                foreach (DataGridViewRow dgvrCat in dataGridViewCategory.Rows)
                {
                    if (dgvrCat.Cells[1].Value.ToString() == tb_NamaCat.Text)
                    {
                        kembar = true;
                        break;
                    }
                    else
                    {
                        kembar = false;
                    }
                }

                if (kembar == true)
                {
                    MessageBox.Show("Category sudah ada", "Eror", MessageBoxButtons.OK);

                }
                else if (kembar == false)
                {
                    string catTerakhir = dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString();
                    int berapa = int.Parse(catTerakhir.ToString().Substring(1));
                    berapa++;

                    dtCategory.Rows.Add("C" + berapa, tb_NamaCat.Text);

                    cbx_CategoryPro.Items.Add(tb_NamaCat.Text);
                    cbx_Filter.Items.Add(tb_NamaCat.Text);
                    //MessageBox.Show(cbx_CategoryPro.Items.Count.ToString());
                    tb_NamaCat.Clear();
                }
                dataGridViewCategory.ClearSelection();
            }
        }

        private void btn_RemoveCat_Click(object sender, EventArgs e)
        {
            string simpanRemoveC = " ";
            DataGridViewRow dgvrCat = dataGridViewCategory.CurrentRow;
            //DataGridViewRow dgvrPro = dataGridViewProduk.CurrentRow;
            if (dataGridViewCategory.SelectedRows.Count == 1)
            {
                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    if (dgvrCat.Cells[0].Value.ToString() == dtProduct.Rows[i][4].ToString())
                    {
                        //MessageBox.Show(dtProduct.Rows[i][4].ToString());
                        simpanRemoveC = dgvrCat.Cells[0].Value.ToString();
                        dtProduct.Rows.Remove(dtProduct.Rows[i]);
                    }
                }

                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    if (simpanRemoveC == dtProduct.Rows[i][4].ToString())
                    {
                        //MessageBox.Show(dtProduct.Rows[i][i].ToString());
                        dtProduct.Rows.Remove(dtProduct.Rows[i]);
                    }
                }

                cbx_CategoryPro.Items.Remove(dgvrCat.Cells[1].Value.ToString());
                cbx_Filter.Items.Remove(dgvrCat.Cells[1].Value.ToString());
                dataGridViewCategory.Rows.Remove(dgvrCat);
                tb_NamaCat.Clear();
                dataGridViewProduk.ClearSelection();
                dataGridViewCategory.ClearSelection();
            }
            else
            {
                dataGridViewProduk.ClearSelection();
                dataGridViewCategory.ClearSelection();
            }
                
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cbx_Filter.Enabled = true;
            dataGridViewProduk.ClearSelection();
            dataGridViewCategory.ClearSelection();
        }

        private void btn_AddPro_Click(object sender, EventArgs e)
        {
            if (tb_NamaPro.Text.Length == 0 || tb_Harga.Text.Length == 0 || tb_Stock.Text.Length == 0)
            {
                MessageBox.Show("Input yang lengkap ya", "Eror", MessageBoxButtons.OK);
                //hilang();
                dataGridViewProduk.ClearSelection();
            }
            else if (cbx_CategoryPro.SelectedIndex < 0)
            {
                MessageBox.Show("Pilih category dulu ya", "Eror", MessageBoxButtons.OK);
                //hilang();
                dataGridViewProduk.ClearSelection();
            }
            else 
            {
                awalInput = tb_NamaPro.Text.Substring(0, 1).ToUpper();
                int count = 1;

                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    awalTabel = dtProduct.Rows[i][0].ToString().ToUpper();
                    if (awalTabel[0].ToString() == awalInput)
                    {
                        count++;
                    }
                }

                if (count < 10)
                {
                    awalInput += "00" + count;
                }
                else if (count >= 10)
                {
                    awalInput += "0" + count;
                }
                else
                {
                    awalInput += count;
                }

                awalTampil = awalInput;

                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cbx_CategoryPro.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        simpanCatPro = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }
                dtProduct.Rows.Add(awalTampil, tb_NamaPro.Text, tb_Harga.Text, tb_Stock.Text, simpanCatPro);
                hilang();
                dataGridViewProduk.DataSource = dtProduct;
                dataGridViewProduk.ClearSelection();

            }
            
        }

        private void btn_EditPro_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvrPro = dataGridViewProduk.CurrentRow;

            if (dataGridViewProduk.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih produk yang mau di edit terlebih dahulu", "Eror", MessageBoxButtons.OK);
                //hilang();
                dataGridViewProduk.ClearSelection();
            }
            else
            {
                if (tb_Stock.Text == "0")
                {
                    dataGridViewProduk.Rows.Remove(dgvrPro);
                }
                else
                {
                    for (int i = 0; i < dtCategory.Rows.Count; i++)
                    {
                        if (cbx_CategoryPro.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                        {
                            simpanCatPro = dtCategory.Rows[i][0].ToString();
                            break;
                        }
                    }

                    dgvrPro.Cells[1].Value = tb_NamaPro.Text;
                    dgvrPro.Cells[2].Value = tb_Harga.Text;
                    dgvrPro.Cells[3].Value = tb_Stock.Text;
                    dgvrPro.Cells[4].Value = simpanCatPro;

                }

                dataGridViewProduk.Refresh();
                dataGridViewProduk.DataSource = dtProduct;
                hilang();
                dataGridViewProduk.ClearSelection();
            }
        }

        private void btn_RemovePro_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvrPro = dataGridViewProduk.CurrentRow;
            if (dataGridViewProduk.SelectedRows.Count == 1)
            {
                if (dataGridViewProduk.CurrentRow != null)
                {
                    //dataGridViewProduk.Rows.Remove(dgvrPro);
                    for (int i = 0; i < dtProduct.Columns.Count; i++)
                    {
                        for (int j = 0; j < dtProduct.Rows.Count; j++)
                        {
                            if (dgvrPro.Cells[0].Value.ToString() == dtProduct.Rows[j][0].ToString())
                            {
                                dtProduct.Rows.RemoveAt(j);
                                //dataGridViewProduk.Rows.Remove(dataGridViewProduk.CurrentRow);
                                break;
                            }
                            
                        }
                        break;
                    }
                }
                
            }

            dataGridViewProduk.DataSource = dtProduct;
            hilang();
            
            dataGridViewProduk.ClearSelection();
        }

        private void cbx_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string simpanC = " ";
            //DataGridViewRow dgvrPro = dataGridViewProduk.CurrentRow;
            if (cbx_Filter.SelectedItem != null)
            {
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cbx_Filter.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        simpanC = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }

                dtProductTampil = new DataTable();
                dtProductTampil.Columns.Add("ID Product");
                dtProductTampil.Columns.Add("Nama Product");
                dtProductTampil.Columns.Add("Harga");
                dtProductTampil.Columns.Add("Stock");
                dtProductTampil.Columns.Add("ID Category");

                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    if (simpanC == dtProduct.Rows[i][4].ToString())
                    {
                        dtProductTampil.Rows.Add(dtProduct.Rows[i][0], dtProduct.Rows[i][1], dtProduct.Rows[i][2], dtProduct.Rows[i][3], dtProduct.Rows[i][4]);

                    }
                }
                dataGridViewProduk.DataSource = dtProductTampil;
                dataGridViewProduk.ClearSelection();
                dataGridViewCategory.ClearSelection();
            }
            
        }

        private void tb_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void tb_Stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void hilang()
        {
            tb_NamaPro.Clear();
            cbx_CategoryPro.SelectedItem = null;
            tb_Harga.Clear();
            tb_Stock.Clear();
            
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cbx_Filter.Text = null;
            cbx_Filter.Enabled = false;
            dataGridViewProduk.DataSource = dtProduct;
            dataGridViewProduk.ClearSelection();
            dataGridViewCategory.ClearSelection();

        }
    }
}
